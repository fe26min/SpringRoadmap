package jpa.basic.ex1hellojpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Ex1hellojpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
